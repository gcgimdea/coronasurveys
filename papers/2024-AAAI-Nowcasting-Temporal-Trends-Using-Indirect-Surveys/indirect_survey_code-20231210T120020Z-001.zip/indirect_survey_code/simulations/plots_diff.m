%%
xx = load('../latest_us_data.mat', 'data_4', 'popu');
set(0, 'DefaultAxesFontSize', 14, 'defaultfigureposition', [10 10 700 600], 'DefaultLineLineWidth', 1.5, 'defaultAxesFontWeight', 'bold');
addpath('..');
%% For simulation
dd = f_w{1}; sim =1;
dd1 = (dd.*(15*(1-dd)+100.*dd)); % sigma_X^2

%% For real data
ca_curve = smooth_epidata(xx.data_4(3, :), 'cspline'); sim = 0;
[~, ~, ~, ~, ~, ~, ~, f_w_ca] = synth_survey_sim(ca_curve, 0.1, 10, 100, 7, 1, 3);
dd = f_w_ca;
dd1 = (dd.*(15*(1-dd)+100.*dd)); % sigma_X^2

%% f_t
tiledlayout(3, 1);
nexttile; 
plot(dd)
xlabel('t'); ylabel('f_t')
nexttile;
semilogy(abs(diff(dd, 1)./dd(2: end))); hold on
semilogy(abs(diff(dd, 2)./dd(2: end-1)))
%semilogy(abs(diff(dd.^2, 2)./dd(2: end-1).^2))
xlabel('t');
ylabel('Difference'); ylim([0.0001, 0.1])
yticks([0.0001, 0.001, 0.01, 0.1])
%legend({'$\Delta f_t/f_t$', '$\Delta^2 f_t/f_t$', '$\Delta^2 f_t^2/f_t^2$'}, 'Interpreter','latex','FontSize',14);
legend({'$\Delta f_t/f_t$', '$\Delta^2 f_t/f_t$'}, 'Interpreter','latex','FontSize',14);
% sigma^2
nexttile;
semilogy(abs(diff(dd1, 1)./dd1(2: end))); hold on
semilogy(abs(diff(dd1, 2)./dd1(2: end-1)))
%semilogy(abs(diff(dd1.^2, 2)./dd1(2: end-1).^2))
xlabel('t');
ylabel('Difference'); ylim([0.0001, 0.1])
yticks([0.0001, 0.001, 0.01, 0.1])
%legend({'$\Delta \sigma_{X_t}^2/\sigma_{X_t}^2$', '$\Delta^2 \sigma_{X_t}^2/\sigma_{X_t}^2$', '$\Delta^2 \sigma_{X_t}^4/\sigma_{X_t}^4$'}, 'Interpreter','latex','FontSize',14);
legend({'$\Delta \sigma_{X_t}^2/\sigma_{X_t}^2$', '$\Delta^2 \sigma_{X_t}^2/\sigma_{X_t}^2$'}, 'Interpreter','latex','FontSize',14);
%% \gamma_f
sr = 0.3;
str_list = {}; m_list = ["o-", "d-", "s-"];

tiledlayout(3, 1);

nexttile;
plot(dd);
xlabel('t'); ylabel('f_t');
nexttile;
w_list = [1 2 4 8];
for widx = 1:length(w_list)
    w = w_list(widx);
    %Ew = (w*(w+1)+1)./(2*w+1);
    Ew = (w*(w+1))/6;
    e1 = movmax(abs(diff(dd, 1)./dd(2: end)), 2*w+1);
    e2 = movmax(abs(diff(dd, 2)./dd(2: end-1)), 2*w+1);
    e2_2 = movmax(abs(diff(dd.^2, 2)./dd(2: end-1).^2), 2*w+1);
    
    %gam_f = Ew.*e2 + e1(2:end)*sr*sqrt(w*(w+1));
    gam_f = Ew.*e2 + sr*(e1(2:end)*w./(1 - e1(2:end)*w));

    plot([7:7:length(gam_f)], gam_f(7:7:end), m_list(1+mod(w, 3))); hold on;
    str_list = [str_list; {['w = ' num2str(w)]}];
end
ylim([0, 0.25]); xlim([0, inf])
legend(str_list);
xlabel('t'); ylabel('{\boldmath$\gamma_{f}$}', 'Interpreter','latex');

nexttile;
for widx = 1:length(w_list)
    w = w_list(widx);
    %Ew = (w*(w+1)+1)./(2*w+1);
    Ew = (w*(w+1))/6;
    e1 = movmax(abs(diff(dd1, 1)./dd1(2: end)), 2*w+1);
    e2 = movmax(abs(diff(dd1, 2)./dd1(2: end-1)), 2*w+1);
    e2_2 = movmax(abs(diff(dd1.^2, 2)./dd1(2: end-1).^2), 2*w+1);
    %gam_f = Ew.*e2 + e1(2:end)*sr*sqrt(w*(w+1));
    gam_f = Ew.*e2 + sr*(e1(2:end)*w./(1 - e1(2:end)*w));
    plot([7:7:length(gam_f)], gam_f(7:7:end), m_list(1+mod(w, 3))); hold on;
    str_list = [str_list; {['w = ' num2str(w)]}];
end
ylim([0, 0.25]); xlim([0, inf])
legend(str_list);
xlabel('t'); ylabel('{\boldmath${\gamma_{\sigma^2}}$}', 'Interpreter','latex');