function [in_resp_w_s, d_resp_w_s, true_infec_w, in_resp_w_s1, d_resp_w_s1, nsum_w_s, nsum_w_s1, f_w, in_resp_w, d_resp_w, nsum_w, nt_w, in_resp, d_resp, f, nt] = synth_survey_sim(true_infec, rho, N, Nd, period, accum, ww, dynamic_graph)
if nargin < 8
    dynamic_graph = 1;
end
if nargin < 7
    ww = 1;
end
N0 = N;
T = length(true_infec);
%period = 7; % Question asks about last week.
nsum = nan(T, 1);
in_resp = nan(T, 1);
d_resp = nan(T, 1);
f = nan(T, 1);
nt = N*ones(T, 1);

d = rho*Nd;


for t=(period+1):T
    N = randi(N0);
    yy = randsample((Nd/2), N, true, ([1:floor(Nd/2)].^(-2)));
    rho = (d*yy./mean(yy))/Nd;

    f(t) = (true_infec(t) - true_infec(t-period));
    if dynamic_graph == 1
        G = sparse(rand(N, Nd)) <= rho;
    end
    %sel = rand(N, 1) < pn; 
    sel = ones(N, 1);
    if sum(sel) < 1
        sel(1) = 1;
    end
    degs = sum(G, 2);
    inf_state = binornd(1, f(t), [Nd 1]);
    in_resp(t) = sum(sel.*(G*inf_state), 'all');
    nsum(t) = sum(sel.*(G*inf_state)./(1e-10 + degs), 'all');
    inf_state = binornd(1, f(t), [N 1]);
    d_resp(t) = sum(sel.*inf_state, 'all');
    nt(t) = sum(sel);
end
% Aggregate answers over weeks
%accum = 7;
f_w = cumsum(f, 'omitnan'); f_w = diff(f_w(accum:accum:end));
true_infec_w = true_infec'; true_infec_w = diff(true_infec_w(accum:accum:end));
in_resp_w = cumsum(in_resp, 'omitnan'); in_resp_w = diff(in_resp_w(accum:accum:end));
d_resp_w = cumsum(d_resp, 'omitnan'); d_resp_w = diff(d_resp_w(accum:accum:end));
nt_w = cumsum(nt, 'omitnan'); nt_w = diff(nt_w(accum:accum:end));
nsum_w = cumsum(nsum, 'omitnan'); nsum_w = diff(nsum_w(accum:accum:end));

% in_resp_w_s = csaps(1:length(in_resp_w), in_resp_w, 0.5, (1:length(in_resp_w))');
% in_resp_w_s(in_resp_w_s<0) = 1e-20;
% d_resp_w_s = csaps(1:length(d_resp_w), d_resp_w, 0.5, (1:length(d_resp_w))');

in_resp_w_s1 = movmean(in_resp_w, [ww ww]);
nsum_w_s1 = movmean(nsum_w, [ww ww]);
d_resp_w_s1 = movmean(d_resp_w, [ww ww]);

ll = length(in_resp_w_s1);
in_resp_w_s = in_resp_w_s1;
d_resp_w_s = d_resp_w_s1;
nsum_w_s = nsum_w_s1;

for ii = 1:ll
    rr = [max(1, ii-ww):min(ll, ii+ww)];
    in_resp_w_s(ii) = sum(nt_w(rr).*in_resp_w(rr))./(sum(nt_w(rr)));
    d_resp_w_s(ii) = sum(nt_w(rr).*d_resp_w(rr))./(sum(nt_w(rr)));
    nsum_w_s(ii) = sum(nt_w(rr).*nsum_w(rr))./(sum(nt_w(rr)));
end

end