load matlab;
%%
% N = 50; % no. of survey participants
% Nd = 500; % no. of individuals the participants can cover
% d = 15; % approx. average degree
% rho = d/(Nd-1);
% G = sparse(rand(N, Nd)) <= rho; % Erdos-Renyi graph
% d_true = mean(sum(G, 2));
dynamic_graph = 1; % Means each day the survey may cover a different "graph"
%%
cid = 5;    % Change this to select a different region
T = size(data_4, 2);
%true_infec = cumsum(true_uns(cid, :).*[0 diff(data_4(cid, :))], 'omitnan');
true_infec = cumsum(true_infecs(cid, :))/popu(cid);

d_list = [5:5:20]; % Average degree of each node
N_list = 10*2.^([0:1:3]); % Number of participants on each day
Nd_list = 30*2.^([1:4]); % Total population these participants could potentially cover
accum_list = [1 7 14 28]; % Over how many days should we accumulate responses   
period_list = [7 14 28 35]; % How many people do you know who were infected in the last "period" days 
w_list = [1 2 4 8];
sim_list = [1:16]; % Simulation id for each combination form above. [1:5] will run each combination 5 times
[X1, X2, X3, X4, X5, X6, X7] = ndgrid(d_list, N_list, Nd_list, accum_list, period_list, w_list, sim_list);
scen_list = [X1(:), X2(:), X3(:) X4(:) X5(:) X6(:) X7(:)];
%%
parfor ss = 1:size(scen_list, 1)
    d = scen_list(ss, 1);
    N = scen_list(ss, 2);
    Nd = scen_list(ss, 3);
    period = scen_list(ss, 5);
    accum = scen_list(ss, 4);
    w = scen_list(ss, 6);
    rho = d/(Nd-1);
     [in_resp_w_s{ss}, d_resp_w_s{ss}, true_infec_w{ss}, in_resp_w_s1{ss}, d_resp_w_s1{ss}, nsum_w_s{ss}, nsum_w_s1{ss}, f_w{ss}, in_resp_w{ss}, d_resp_w{ss}, nsum_w{ss}, nt_w{ss}, in_resp{ss}, d_resp{ss}, f{ss}, nt{ss}] = synth_survey_sim(true_infec, rho, N, Nd, period, accum, w);
    if mod(ss, 50) == 0
        fprintf('.');
    end
end
fprintf('\n')

%% Evaluate errors
ae_mean = nan(size(scen_list, 1), 9);
ae_median = nan(size(scen_list, 1), 9);
p_corr = nan(size(scen_list, 1), 9);
for ss = 1:size(scen_list, 1)
    xx = true_infec_w{ss}./max(true_infec_w{ss});
    yy1 = in_resp_w{ss}./max(in_resp_w{ss});
    yy2 = in_resp_w_s{ss}./max(in_resp_w_s{ss});
    yy3 = in_resp_w_s1{ss}./max(in_resp_w_s1{ss});
    yy4 = nsum_w{ss}./max(nsum_w{ss});
    yy5 = nsum_w_s{ss}./max(nsum_w_s{ss});
    yy6 = nsum_w_s1{ss}./max(nsum_w_s1{ss});
    yy7 = d_resp_w{ss}./max(d_resp_w{ss});
    yy8 = d_resp_w_s{ss}./max(d_resp_w_s{ss});
    yy9 = d_resp_w_s1{ss}./max(d_resp_w_s1{ss});
    

    ae_mean(ss, 1) = mean(abs(yy1 - xx)); ae_median(ss, 1) = median(abs(yy1 - xx)./xx);
    ae_mean(ss, 2) = mean(abs(yy2 - xx)); ae_median(ss, 2) = median(abs(yy2 - xx)./xx);
    ae_mean(ss, 3) = mean(abs(yy3 - xx)); ae_median(ss, 3) = median(abs(yy3 - xx)./xx);
    ae_mean(ss, 4) = mean(abs(yy4 - xx)); ae_median(ss, 4) = median(abs(yy4 - xx)./xx);
    ae_mean(ss, 5) = mean(abs(yy5 - xx)); ae_median(ss, 5) = median(abs(yy5 - xx)./xx);
    ae_mean(ss, 6) = mean(abs(yy6 - xx)); ae_median(ss, 6) = median(abs(yy6 - xx)./xx);
    ae_mean(ss, 7) = mean(abs(yy7 - xx)); ae_median(ss, 7) = median(abs(yy7 - xx)./xx);
    ae_mean(ss, 8) = mean(abs(yy8 - xx)); ae_median(ss, 8) = median(abs(yy8 - xx)./xx);
    ae_mean(ss, 9) = mean(abs(yy9 - xx)); ae_median(ss, 9) = median(abs(yy9 - xx)./xx);

    p_corr(ss, 1) = corr(yy1, xx);
    p_corr(ss, 2) = corr(yy2, xx);
    p_corr(ss, 3) = corr(yy3, xx);
    p_corr(ss, 4) = corr(yy4, xx);
    p_corr(ss, 5) = corr(yy5, xx);
    p_corr(ss, 6) = corr(yy6, xx);
    
end

%%
set(0, 'DefaultAxesFontSize', 14, 'defaultfigureposition', [10 10 800 300], 'DefaultLineLineWidth', 1.5, 'defaultAxesFontWeight', 'bold');

%% Error vs N
sel_var = 5; % Ordering [d, N, Nd, period, accum]
var_names = {'d', 'n', 'n_d', 'accum', 'period', 'w'};
tiledlayout(1, 4, 'TileSpacing', 'tight');
this_list = unique(scen_list(:, sel_var));
for nn = 1:length(this_list)
    %scen_idx = find(scen_list(:, sel_var) == this_list(nn) & scen_list(:, 6) == 1 & scen_list(:, 4) == 14);
    scen_idx = find(scen_list(:, sel_var) == this_list(nn));
    
    nexttile; bh = boxplot(ae_mean(scen_idx, :), {'Ind-NoS', 'Ind-WA', 'Ind-UA', ...
        'NSUM-NoS', 'NSUM-WA', 'NSUM-UA', 'Dir-NoS', 'Dir-WA', 'Dir-UA'}); 
    title([var_names{sel_var} ' = ' num2str(this_list(nn))]);
    ylim([0, 0.5])
    if nn==1
        ylabel('MAE')
    end
    set(bh,'LineWidth',1);
end
saveas(gcf, ['./figs/ae_' var_names{sel_var} '.png']);
%%
%% Error vs N
sel_var = 6; % Ordering [d, N, Nd, period, accum]
var_names = {'d', 'n', 'n_d', 'accum', 'period', 'w'};
tiledlayout(1, 4, 'TileSpacing', 'tight');
fix_array = [5 20 60 7 7 2];

selector = ones(size(scen_list, 1), 1);
for vv = 1:length(fix_array)
    if vv ~= sel_var
        selector = selector & scen_list(:, vv) == fix_array(vv);
    end
end

this_list = unique(scen_list(:, sel_var));
for nn = 1:length(this_list)
    scen_idx = find(scen_list(:, sel_var) == this_list(nn) & selector) ;
    %scen_idx = find(scen_list(:, sel_var) == this_list(nn));
    
    nexttile; bh = boxplot(ae_mean(scen_idx, :),{'Ind-NoS', 'Ind-WA', 'Ind-UA', ...
        'NSUM-NoS', 'NSUM-WA', 'NSUM-UA', 'Dir-NoS', 'Dir-WA', 'Dir-UA'}); 
    title([var_names{sel_var} ' = ' num2str(this_list(nn))]);
    ylim([0, 0.35])
    yticks([0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35]);
    if nn==1
        ylabel('MAE')
    else
        set(gca, 'YtickLabel', []);
    end
    set(bh,'LineWidth',1);
    %xticks([3.5, 6.5]);
    set(gca, 'YGrid','on');
end
%saveas(gcf, ['./figs/ae_' var_names{sel_var} '_sel.png']);
%%
scen_idx = find(scen_list(:, 2) == 20 & scen_list(:, 4) == 1);
boxplot(ae_mean(scen_idx, :), {'Indirect1', 'Direct1', 'Indirect2', 'Direct2', 'Indirect0', 'Direct0'}); 
%% Corr vs N
sel_var = 6; % Ordering [d, N, Nd, period, accum]
var_names = {'d', 'n', 'n_d', 'accum', 'period', 'w'};
tiledlayout(1, 4);
this_list = unique(scen_list(:, sel_var));
for nn = 1:length(this_list)
    scen_idx = find(scen_list(:, sel_var) == this_list(nn));
    %scatter(repmat(N_list(nn), [length(scen_idx) 4]), ae_mean(scen_idx, :), 'o'); hold on;
    nexttile; bh = boxplot(p_corr(scen_idx, :), {'Indirect1', 'Direct1', 'Indirect2', 'Direct2', 'Indirect0', 'Direct0'}); 
    title([var_names{sel_var} ' = ' num2str(this_list(nn))]);
    ylim([0.3, 1])
    if nn==1
        ylabel('Corr');
    end
    set(bh,'LineWidth',1);
end
saveas(gcf, ['./figs/corr_' var_names{sel_var} '.png']);

%% Analyze the fit for specific simulation
full_t = tiledlayout(3, 1);
ss = 168; % simulation number
nexttile;

plot(normalize(true_infec_w{ss}, 'range')); hold on;
%plot(normalize(in_resp_w{ss}, 'range'), 'o'); hold on;
plot(normalize([in_resp_w_s1{ss} in_resp_w_s{ss}], 'range'));
legend({'True Infections'; 'Unweighted Average'; 'Weighted Average'});
title(['Indirect estimates']);

nexttile;
plot(normalize(true_infec_w{ss}, 'range')); hold on;
%plot(normalize(d_resp_w, 'range'), 'o'); hold on;
plot(normalize([nsum_w_s1{ss} nsum_w_s{ss}], 'range'));
legend({'True Infections'; 'Unweighted Average'; 'Weighted Average'});
title(['NSUM']);

nexttile;
plot(normalize(true_infec_w{ss}, 'range')); hold on;
%plot(normalize(d_resp_w, 'range'), 'o'); hold on;
plot(normalize([d_resp_w_s1{ss} d_resp_w_s{ss}], 'range'));
legend({'True Infections'; 'Unweighted Average'; 'Weighted Average'});
title(['Direct estimates']);


title(full_t, ['d= ' num2str(scen_list(ss, 1)) ', n= ' num2str(scen_list(ss, 2)) ', n_d = ' num2str(scen_list(ss, 3)) ...
    ', accum= ' num2str(scen_list(ss, 4)) ', period= ' num2str(scen_list(ss, 5)) ', w = ' num2str(scen_list(ss, 6))]);
%%

param_table = array2table([(1:size(scen_list))' scen_list ae_mean(:, 1)], 'VariableNames', {'idx', 'd', 'N', 'Nd', 'accum', 'period', 'w', 'sim_num', 'MAE'});
groupsummary(param_table, ["d"; "N"; "Nd"; "accum"; "period"; "w"], 'mean', 'MAE' );
param_table_grouped = groupsummary(param_table, ["d"; "N"; "Nd"; "accum"; "period"; "w"], 'mean', 'MAE' );
param_table_grouped_s = sortrows(param_table_grouped, 'mean_MAE', 'ascend');