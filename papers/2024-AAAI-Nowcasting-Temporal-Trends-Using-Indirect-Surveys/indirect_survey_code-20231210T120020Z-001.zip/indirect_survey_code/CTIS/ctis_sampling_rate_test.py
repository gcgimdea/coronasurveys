# Import libraries
import os
import scipy.io
import scipy.stats as st
import pandas as pd
import numpy as np
from csaps import csaps
import scipy.stats

# Ploting libraries
import matplotlib.pyplot as plt
import seaborn as sn
from datetime import datetime, timedelta

import matplotlib.dates as mdates
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
dtFmt = mdates.DateFormatter('%b-%Y') 

# Our functions
def normalization(input_vector):
    min_data = np.min(input_vector)
    max_data = np.max(input_vector)
    output_vector = (input_vector - min_data) / (max_data - min_data)
    return output_vector


def quality_metrics(input_vector, reference):
    input_vector = normalization(input_vector)
    reference = normalization(reference)
    output_vector = np.zeros(6)
    output_vector[0] = scipy.stats.pearsonr(input_vector.reshape(-1), reference.reshape(-1))[0] # pearson
    output_vector[1] = scipy.stats.spearmanr(input_vector, reference)[0] # spearman
    output_vector[2] = scipy.stats.kendalltau(input_vector, reference)[0] # kendall
    output_vector[3] = np.mean(np.power(input_vector-reference,2)) # mse
    output_vector[4] = np.sum(np.power(input_vector-reference,2)) # sse
    output_vector[5] = np.mean(np.absolute(input_vector-reference)) #mae
    return output_vector

def weighted_moving_average(input_vector, weights, window_size):
    output_vector = np.zeros(len(input_vector))
    for i in range(window_size//2, len(input_vector) - (window_size//2)):
        d = input_vector[i - (window_size//2):i + (window_size//2)]
        w = weights[i - (window_size//2):i + (window_size//2)]
        if (np.sum(w) == 0):
            w = np.ones(len(w))*(1/len(w))
        else:
            w = w / np.sum(w)
        output_vector[i] = np.dot(d,w)
    return output_vector

# Files and number of aggregation days
T = 7
# files = os.listdir('ctis_data/')
# files = files[0:5]
files = ['California.csv', 'Texas.csv', 'New York.csv', 'Pennsylvania.csv']
acr_files = ['CA', 'TX', 'NY', 'PN']
trials = 25
sampling_rate = 3


# Official data
us_data = pd.read_csv("us_data.csv", sep=",")
us_data = us_data.transpose()
official_data = pd.DataFrame(columns=[us_data.iloc[1].to_list()])
official_data[us_data.iloc[1].to_list()] = us_data.iloc[2:]

series_aux = official_data.index.to_list()
series_aux = pd.to_datetime(series_aux)
official_data['date'] = series_aux
official_data = official_data[pd.to_datetime(official_data.index.to_list()) > np.datetime64('2020-09-08')]
official_data = official_data[pd.to_datetime(official_data.index.to_list()) < np.datetime64('2022-03-01')]


official    = []
dates_x     = []
household   = []
directraw   = []
directmav   = []
movingavg   = []
community   = []
nsum        = []

ci1 = []
ci2 = []
ci3 = []

qq = 0
for f in files:
    print(f)
    data = pd.read_csv("ctis_data/" + f, sep=",")
    data['EndDatetime'] = pd.to_datetime(data['EndDatetime']).dt.date
    data = data[data['EndDatetime'] > np.datetime64('2020-09-07')]
    data = data[data['EndDatetime'] < np.datetime64('2022-03-01')] 
    household_data  = data.copy()
    household_data = household_data[['EndDatetime', 
                                     'A2', 
                                     'A1_1', 
                                     'A1_3', 
                                     'A1_4', 
                                     'A1_5',
                                     'A4', 
                                     'A2b',
                                     'A5_1', 
                                     'A5_2', 
                                     'A5_3',
                                     'weight']]
    direct_data = data.copy()
    direct_data = direct_data[['EndDatetime', 
                                     'B10a', 
                                     'B10c']]
    direct_data['B10'] = ((direct_data['B10a'] == 1.0) | (direct_data['B10c'] == 1.0)).astype(int)
    direct_data = direct_data[direct_data['B10'] == 1]
    

    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]._convert(numeric=True)
    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']].fillna(0)
    household_data[['A2b']] = household_data[['A2b']].fillna(0)
    household_data['A5'] = np.sum(np.array(household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]),axis=1)
    
    household_data['A4'] = household_data['A4'].astype('float')
    # -------------------------------------------------
    # NaN filtering across rows and outlier detection
    household_data = household_data.dropna(axis=0)    
    UB = household_data['A2'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A2'] > 0) & (household_data['A2'] < UB)]
    UB = household_data['A4'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A4'] > 0) & (household_data['A4'] < UB)]
    # Defining household CLI
    household_data['CLI'] = (household_data['A1_1'] == 1) & ((household_data['A1_3'] ==1) | (household_data['A1_4'] == 1) | (household_data['A1_3'] == 1))
    household_data['A2'] = np.multiply(household_data['A2'], household_data['CLI'].astype(float))
    
    cli_condition = (household_data['A2'] > 0) | (household_data['A4'] > 0) 
    cli_data = household_data.copy()
    cli_data = cli_data[cli_condition == True]
    cli_data['A4'] = np.multiply(cli_data['A2'] + cli_data['A4'], cli_data['CLI'].astype(float))

    # -------------------------------------------------
    # Extracting information from the facebook dataset    
    dates = np.unique(household_data['EndDatetime'])
    indirect_raw = np.zeros(len(dates))
    direct_raw = np.zeros(len(dates))
    cli_raw = np.zeros(len(dates))
    official_cum_cases = np.zeros(len(dates))
    nsum_raw = np.zeros(len(dates))
    no_responses1 = np.zeros(len(dates))
    no_responses2 = np.zeros(len(dates))
    no_responses3 = np.zeros(len(dates))
    
    mae = np.zeros((trials,3)) 
    for jj in range(trials):
        print(jj)
        for i in range(len(dates)):
            one_positions1 = (np.random.uniform(size=household_data['A2'][household_data['EndDatetime'] == dates[i]].shape[0]) < (sampling_rate/100))
            one_positions2 = (np.random.uniform(size=direct_data['B10'][direct_data['EndDatetime'] == dates[i]].shape[0]) < (sampling_rate/100))
            one_positions3 = (np.random.uniform(size=cli_data['A4'][cli_data['EndDatetime'] == dates[i]].shape[0]) < (sampling_rate/100))        

            indirect_raw[i] = np.sum(household_data['A2'][household_data['EndDatetime'] == dates[i]][one_positions1])
            no_responses1[i] = household_data['A2'][household_data['EndDatetime'] == dates[i]][one_positions1].shape[0]
            
            direct_raw[i] = np.sum(direct_data['B10'][direct_data['EndDatetime'] == dates[i]][one_positions2])
            no_responses2[i] = direct_data['B10'][direct_data['EndDatetime'] == dates[i]][one_positions2].shape[0]
            
            cli_raw[i] = np.sum(cli_data['A4'][cli_data['EndDatetime'] == dates[i]][one_positions3])
            no_responses3[i] = cli_data['A4'][cli_data['EndDatetime'] == dates[i]][one_positions3].shape[0]

            reach = np.sum(household_data['A5'][household_data['EndDatetime'] == dates[i]][one_positions1])
            official_cum_cases[i] = np.sum(official_data[f.replace('.csv', '')][pd.to_datetime(official_data.index.to_list()).date == dates[i]])
        
        indirect_raw_cum = np.cumsum(indirect_raw)
        indirect_raw_stt = np.diff(indirect_raw_cum[T-1::T])      
        direct_raw_cum = np.cumsum(direct_raw)
        direct_raw_stt = np.diff(direct_raw_cum[T-1::T])   
        cli_raw_cum = np.cumsum(cli_raw)
        cli_raw_stt = np.diff(cli_raw_cum[T-1::T])    
    
        w_cum1 = np.cumsum(no_responses1)
        weights1 = np.diff(w_cum1[T-1::T])
        w_cum2 = np.cumsum(no_responses2)
        weights2 = np.diff(w_cum2[T-1::T])
        w_cum3 = np.cumsum(no_responses3)
        weights3 = np.diff(w_cum3[T-1::T])
    
    
        # -------------------------------------------------
        # Raw data
        official_new_cases = np.diff(official_cum_cases[T-1::T].T)
        # -------------------------------------------------
        # Moving average
        window_size = 5
        # mvavg = np.convolve(indirect_raw_stt, np.ones((window_size,))/window_size, mode='same')
        mvavg = weighted_moving_average(indirect_raw_stt, weights1, window_size)
        mvavg = mvavg[(window_size//2):len(mvavg) - (window_size//2)]
        
       
        # mvavd = np.convolve(direct_raw_stt, np.ones((window_size,))/window_size, mode='same')
        mvavd = weighted_moving_average(direct_raw_stt, weights2, window_size)
        mvavd = mvavd[(window_size//2):len(mvavd) - (window_size//2)]
    
        # mvavc = np.convolve(cli_raw_stt, np.ones((window_size,))/window_size, mode='same')
        mvavc = weighted_moving_average(cli_raw_stt, weights3, window_size)
        mvavc = mvavc[(window_size//2):len(mvavc) - (window_size//2)]
 
        if (jj == 0):
            mavg_v = normalization(mvavg)
            mavd_v = normalization(mvavd)
            mavc_v = normalization(mvavc)
        else:
            mavg_v = np.vstack((mavg_v, normalization(mvavg)))
            mavd_v = np.vstack((mavd_v, normalization(mvavd)))
            mavc_v = np.vstack((mavc_v, normalization(mvavc)))
 
    
        indirect_raw_stt = indirect_raw_stt[(window_size//2):len(indirect_raw_stt) - (window_size//2)]
        direct_raw_stt = direct_raw_stt[(window_size//2):len(direct_raw_stt) - (window_size//2)]
        # nsum_raw_stt = nsum_raw_stt[(window_size//2):len(nsum_raw_stt) - (window_size//2)]
        official_new_cases = official_new_cases.T[(window_size//2):len(official_new_cases) - (window_size//2)]
    

        metrics_hs = quality_metrics(normalization(mvavg.reshape(-1,1)), 
                                     normalization(official_new_cases.reshape(-1,1)))
        mae[jj,1] = metrics_hs[5]
        
        metrics_ds = quality_metrics(normalization(mvavd.reshape(-1,1)), 
                                     normalization(official_new_cases.reshape(-1,1)))
        mae[jj,2] = metrics_ds[5]
        
        metrics_cs = quality_metrics(normalization(direct_raw_stt.reshape(-1,1)), 
                                     normalization(official_new_cases.reshape(-1,1)))
        mae[jj,0] = metrics_cs[5]
    
    agg_dates = dates[T-1::T]
    agg_dates = agg_dates[1 + (window_size//2):len(agg_dates) - (window_size//2)]
    
    official.append(normalization(official_new_cases.reshape(-1,1)))
    household.append(normalization(indirect_raw_stt.reshape(-1,1)))
    directraw.append(normalization(direct_raw_stt.reshape(-1,1)))
    movingavg.append(np.mean(mavg_v, axis=0).reshape(-1,1))
    directmav.append(np.mean(mavd_v, axis=0).reshape(-1,1))
    community.append(np.mean(mavc_v, axis=0).reshape(-1,1))
    ci1.append(st.norm.interval(alpha=0.95, loc=np.mean(mavg_v, axis=0), scale=st.sem(mavg_v, axis=0)))
    ci2.append(st.norm.interval(alpha=0.95, loc=np.mean(mavd_v, axis=0), scale=st.sem(mavd_v, axis=0)))
    ci3.append(st.norm.interval(alpha=0.95, loc=np.mean(mavc_v, axis=0), scale=st.sem(mavc_v, axis=0)))
    
    dates_x.append(agg_dates.reshape(-1,1))    

    grg = st.norm
    
    print(mae)
    fig = plt.figure(dpi=300, figsize=(1.80,4))
    plt.boxplot(mae, widths=0.6,
                boxprops=dict(color='b', lw=2),
                medianprops=dict(color='r', lw=2),
                flierprops=dict(marker='+', markerfacecolor='r'),
                whiskerprops=dict(linestyle='--', lw=2))
    plt.ylim((0.00,0.15))
    plt.xticks(np.linspace(1,3,3), ['Community', 'Household', 'Direct'], rotation='vertical', fontsize=14, fontweight='bold')
    plt.yticks(np.linspace(0, 0.15,4), fontsize=14, fontweight='bold')
    if (qq==0):
        plt.ylabel('MAE', fontsize=18, fontweight='bold')
    plt.title(acr_files[qq], fontsize=18, fontweight='bold')
    plt.savefig('sampling_rate_test_results/agg%dd/svg_boxplots/sr_%d_accum_%d_w_%d_%s.svg'%(T,sampling_rate, T, window_size//2, acr_files[qq]), bbox_inches='tight')
    plt.show()
    qq +=1
    

new_colors = ['#0072BD', '#D95319', '#EDB120', '#7E2F8E',
              '#77AC30', '#4DBEEE', '#A2142F', '#7f7f7f',
              '#bcbd22', '#17becf']

for i in range(len(files)):
    fig = plt.figure(dpi=300, figsize=(10,2))
    plt.gca().xaxis.set_major_formatter(dtFmt) 
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=4))
    plt.plot(dates_x[i], directmav[i], c = new_colors[0], fillstyle='none', lw = 3,label='Direct')
    plt.fill_between(dates_x[i].reshape(-1), ci2[i][0], ci2[i][1], color=new_colors[0], alpha=0.25)
    
    plt.plot(dates_x[i], movingavg[i], c = new_colors[1], fillstyle='none', lw = 3, label='Household')
    plt.fill_between(dates_x[i].reshape(-1), ci1[i][0], ci1[i][1], color=new_colors[1], alpha=0.25)
    
    plt.plot(dates_x[i], community[i], c = new_colors[2], fillstyle='none', lw = 3, label='Community')
    plt.fill_between(dates_x[i].reshape(-1), ci3[i][0], ci3[i][1], color=new_colors[2], alpha=0.25)
    
    plt.plot(dates_x[i], official[i], 'k--', fillstyle='none', lw = 2, label='Official')
    plt.autoscale(enable=True, axis='x', tight=True)
    plt.ylabel('Incidence', fontsize=16, fontweight='bold')
    plt.xticks(fontsize=14, fontweight='bold')
    plt.yticks(fontsize=14, fontweight='bold')
    plt.legend(fontsize=12)
    plt.title(files[i].replace('.csv', ''), fontsize=16, fontweight='bold')
    plt.savefig('sampling_rate_test_results/agg%dd/svg_figures/'%(T) + files[i].replace('.csv', '') + '.svg', bbox_inches='tight')
    plt.show()