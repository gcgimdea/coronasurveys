# Import libraries
import os
import scipy.io
import pandas as pd
import numpy as np
from csaps import csaps
import scipy.stats

# Ploting libraries
import matplotlib.pyplot as plt
import seaborn as sn
from datetime import datetime, timedelta

import matplotlib.dates as mdates
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes,mark_inset


dtFmt = mdates.DateFormatter('%b-%Y') 

# Our functions
def normalization(input_vector):
    min_data = np.min(input_vector)
    max_data = np.max(input_vector)
    output_vector = (input_vector - min_data) / (max_data - min_data)
    return output_vector


def quality_metrics(input_vector, reference):
    input_vector = normalization(input_vector)
    reference = normalization(reference)
    output_vector = np.zeros(6)
    output_vector[0] = scipy.stats.pearsonr(input_vector.reshape(-1), reference.reshape(-1))[0] # pearson
    output_vector[1] = scipy.stats.spearmanr(input_vector, reference)[0] # spearman
    output_vector[2] = scipy.stats.kendalltau(input_vector, reference)[0] # kendall
    output_vector[3] = np.mean(np.power(input_vector-reference,2)) # mse
    output_vector[4] = np.sum(np.power(input_vector-reference,2)) # sse
    output_vector[5] = np.mean(np.absolute(input_vector-reference)) #mae
    return output_vector

def weighted_moving_average(input_vector, weights, window_size):
    output_vector = np.zeros(len(input_vector))
    for i in range(window_size//2, len(input_vector) - (window_size//2)):
        d = input_vector[i - (window_size//2):i + (window_size//2)]
        w = weights[i - (window_size//2):i + (window_size//2)]
        if (np.sum(w) == 0):
            w = np.ones(len(w))*(1/len(w))
        else:
            w = w / np.sum(w)
        output_vector[i] = np.dot(d,w)
    return output_vector

# Files and number of aggregation days
T = 1
# files = os.listdir('ctis_data/')
# files = files[0:5]
files = ['California.csv', 'Texas.csv', 'New York.csv', 'Pennsylvania.csv']

# Official data
us_data = pd.read_csv("us_data.csv", sep=",")
us_data = us_data.transpose()
official_data = pd.DataFrame(columns=[us_data.iloc[1].to_list()])
official_data[us_data.iloc[1].to_list()] = us_data.iloc[2:]

series_aux = official_data.index.to_list()
series_aux = pd.to_datetime(series_aux)
official_data['date'] = series_aux
official_data = official_data[pd.to_datetime(official_data.index.to_list()) > np.datetime64('2020-09-08')]
official_data = official_data[pd.to_datetime(official_data.index.to_list()) < np.datetime64('2022-03-01')]


official    = []
officialsmth= []
dates_x     = []
household   = []
directraw   = []
directmav   = []
movingavg   = []
community   = []
communityraw= []
nsum        = []

for f in files:
    print(f)
    data = pd.read_csv("ctis_data/" + f, sep=",")
    data['EndDatetime'] = pd.to_datetime(data['EndDatetime']).dt.date
    data = data[data['EndDatetime'] > np.datetime64('2020-09-07')]
    data = data[data['EndDatetime'] < np.datetime64('2022-03-01')] 
    household_data  = data.copy()
    household_data = household_data[['EndDatetime', 
                                     'A2', 
                                     'A1_1', 
                                     'A1_3', 
                                     'A1_4', 
                                     'A1_5',
                                     'A4', 
                                     'A2b',
                                     'A5_1', 
                                     'A5_2', 
                                     'A5_3',
                                     'weight']]
    direct_data = data.copy()
    direct_data = direct_data[['EndDatetime', 
                                     'B10a', 
                                     'B10c']]
    direct_data['B10'] = ((direct_data['B10a'] == 1.0) | (direct_data['B10c'] == 1.0)).astype(int)
    direct_data = direct_data[direct_data['B10'] == 1]
    

    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]._convert(numeric=True)
    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']].fillna(0)
    household_data[['A2b']] = household_data[['A2b']].fillna(0)
    household_data['A5'] = np.sum(np.array(household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]),axis=1)
    
    household_data['A4'] = household_data['A4'].astype('float')
    # -------------------------------------------------
    # NaN filtering across rows and outlier detection
    household_data = household_data.dropna(axis=0)    
    UB = household_data['A2'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A2'] > 0) & (household_data['A2'] < UB)]
    UB = household_data['A4'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A4'] > 0) & (household_data['A4'] < UB)]
    # Defining household CLI
    household_data['CLI'] = (household_data['A1_1'] == 1) & ((household_data['A1_3'] ==1) | (household_data['A1_4'] == 1) | (household_data['A1_3'] == 1))
    household_data['A2'] = np.multiply(household_data['A2'], household_data['CLI'].astype(float))
    
    cli_condition = (household_data['A2'] > 0) | (household_data['A4'] > 0) 
    cli_data = household_data.copy()
    cli_data = cli_data[cli_condition == True]
    cli_data['A4'] = np.multiply(cli_data['A2'] + cli_data['A4'], cli_data['CLI'].astype(float))

    # -------------------------------------------------
    # Extracting information from the facebook dataset    
    dates = np.unique(household_data['EndDatetime'])
    indirect_raw = np.zeros(len(dates))
    direct_raw = np.zeros(len(dates))
    cli_raw = np.zeros(len(dates))
    official_cum_cases = np.zeros(len(dates))
    no_responses1 = np.zeros(len(dates))
    no_responses2 = np.zeros(len(dates))
    no_responses3 = np.zeros(len(dates))
    for i in range(len(dates)):
        indirect_raw[i] = np.sum(household_data['A2'][household_data['EndDatetime'] == dates[i]])
        no_responses1[i] = household_data['A2'][household_data['EndDatetime'] == dates[i]].shape[0]
        direct_raw[i] = np.sum(direct_data['B10'][direct_data['EndDatetime'] == dates[i]])
        no_responses2[i] = direct_data['B10'][direct_data['EndDatetime'] == dates[i]].shape[0]
        cli_raw[i] = np.sum(cli_data['A4'][cli_data['EndDatetime'] == dates[i]])
        no_responses3[i] = cli_data['A4'][cli_data['EndDatetime'] == dates[i]].shape[0]
        official_cum_cases[i] = np.sum(official_data[f.replace('.csv', '')][pd.to_datetime(official_data.index.to_list()).date == dates[i]])
        
    indirect_raw_cum = np.cumsum(indirect_raw)
    indirect_raw_stt = np.diff(indirect_raw_cum[T-1::T])      
    direct_raw_cum = np.cumsum(direct_raw)
    direct_raw_stt = np.diff(direct_raw_cum[T-1::T])   
    cli_raw_cum = np.cumsum(cli_raw)
    cli_raw_stt = np.diff(cli_raw_cum[T-1::T])      
    
    w_cum1 = np.cumsum(no_responses1)
    weights1 = np.diff(w_cum1[T-1::T])
    w_cum2 = np.cumsum(no_responses2)
    weights2 = np.diff(w_cum2[T-1::T])
    w_cum3 = np.cumsum(no_responses3)
    weights3 = np.diff(w_cum3[T-1::T])
    
    
    # -------------------------------------------------
    # Raw data
    official_new_cases = np.diff(official_cum_cases[T-1::T].T)
    # -------------------------------------------------
    # Moving average
    window_size = 15
    # mvavg = np.convolve(indirect_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavg = weighted_moving_average(indirect_raw_stt, weights1, window_size)
    mvavg = mvavg[(window_size//2):len(mvavg) - (window_size//2)]
    
    # mvavd = np.convolve(direct_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavd = weighted_moving_average(direct_raw_stt, weights2, window_size)
    mvavd = mvavd[(window_size//2):len(mvavd) - (window_size//2)]
    
    # mvavc = np.convolve(cli_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavc = weighted_moving_average(cli_raw_stt, weights3, window_size)
    mvavc = mvavc[(window_size//2):len(mvavc) - (window_size//2)]
    
    mvavo = weighted_moving_average(official_new_cases, np.ones(len(official_new_cases)), window_size)
    mvavo = mvavo[(window_size//2):len(mvavo) - (window_size//2)]
    
    print(len(mvavc), len(mvavo))
    
    indirect_raw_stt = indirect_raw_stt[(window_size//2):len(indirect_raw_stt) - (window_size//2)]
    direct_raw_stt = direct_raw_stt[(window_size//2):len(direct_raw_stt) - (window_size//2)]
    cli_raw_stt = cli_raw_stt[(window_size//2):len(cli_raw_stt) - (window_size//2)]
    official_new_cases = official_new_cases.T[(window_size//2):len(official_new_cases) - (window_size//2)]
    
    agg_dates = dates[T-1::T]
    agg_dates = agg_dates[1 + (window_size//2):len(agg_dates) - (window_size//2)]
    
    official.append(normalization(official_new_cases.reshape(-1,1)))
    household.append(normalization(indirect_raw_stt.reshape(-1,1)))
    directraw.append(normalization(direct_raw_stt.reshape(-1,1)))
    movingavg.append(normalization(mvavg.reshape(-1,1)))
    directmav.append(normalization(mvavd.reshape(-1,1)))
    community.append(normalization(mvavc.reshape(-1,1)))
    communityraw.append(normalization(cli_raw_stt.reshape(-1,1)))
    officialsmth.append(normalization(mvavo.reshape(-1,1)))
    
    dates_x.append(agg_dates.reshape(-1,1))


new_colors = ['#0072BD', '#D95319', '#EDB120', '#7E2F8E',
              '#77AC30', '#4DBEEE', '#A2142F', '#7f7f7f',
              '#bcbd22', '#17becf']

for i in range(len(files)):
    fig = plt.figure(dpi=300, figsize=(18, 3))
    ax = plt.subplot(111)
    plt.gca().xaxis.set_major_formatter(dtFmt)
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=4))
    plt.plot(dates_x[i], household[i], 'o-', c=new_colors[1], markersize=3,
             fillstyle='none', lw=2, label='Household Raw')
    plt.plot(dates_x[i], communityraw[i], 's-', c=new_colors[2], markersize=3,
             fillstyle='none', lw=2, label='Community Raw')
    plt.plot(dates_x[i], movingavg[i], c=new_colors[0],
             fillstyle='none', lw=4, label='Household Smoothed')
    plt.plot(dates_x[i], community[i], c=new_colors[3],
             fillstyle='none', lw=4, label='Community Smoothed')
    plt.plot(dates_x[i], officialsmth[i], 'k--',
             fillstyle='none', lw=4, label='Official')
    plt.autoscale(enable=True, axis='x', tight=True)
    plt.ylabel('Incidence', fontsize=24, fontweight='bold')
    plt.xticks(fontsize=22, fontweight='bold')
    plt.yticks(fontsize=22, fontweight='bold')
    
    plt.title(files[i].replace('.csv', ''), fontsize=24, fontweight='bold')

    axins = zoomed_inset_axes(ax, 2.25, loc=9)
    axins.plot(dates_x[i], household[i], 'o-', c=new_colors[1], markersize=3,
             fillstyle='none', lw=2)
    plt.plot(dates_x[i], communityraw[i], 's-', c=new_colors[2], markersize=3,
             fillstyle='none', lw=2)
    plt.plot(dates_x[i], movingavg[i], c=new_colors[0],
             fillstyle='none', lw=4)
    plt.plot(dates_x[i], community[i], c=new_colors[3],
             fillstyle='none', lw=4)
    plt.plot(dates_x[i], officialsmth[i], 'k--',
             fillstyle='none', lw=4,)
    axins.set_xticks([])
    axins.set_yticks([])


    x1, x2, y1, y2 = np.datetime64(
        '2021-12-22'), np.datetime64('2022-02-01'), 0.65, 1.01
    axins.set_xlim(x1, x2)
    axins.set_ylim(y1, y2)

    for axis in ['top','bottom','left','right']:
        axins.spines[axis].set_linewidth(2)

    mark_inset(ax, axins, loc1=1, loc2=4, lw=2)
    ax.legend(fontsize=17, loc='upper right', bbox_to_anchor=(1.00, -0.15),
          fancybox=True, ncol=5)
    plt.savefig('wma_test_curves/agg%dd/svg_figures/'%(T) + files[i].replace('.csv', '') + '.svg', bbox_inches='tight')

    plt.show()