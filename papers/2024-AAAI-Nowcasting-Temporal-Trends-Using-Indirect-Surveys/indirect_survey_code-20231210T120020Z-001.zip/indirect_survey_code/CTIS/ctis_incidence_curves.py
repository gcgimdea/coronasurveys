# Import libraries
import os
import scipy.io
import pandas as pd
import numpy as np
from csaps import csaps
import scipy.stats

# Ploting libraries
import matplotlib.pyplot as plt
import seaborn as sn
from datetime import datetime, timedelta

import matplotlib.dates as mdates
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
dtFmt = mdates.DateFormatter('%b-%Y') 

# Our functions
def normalization(input_vector):
    min_data = np.min(input_vector)
    max_data = np.max(input_vector)
    output_vector = (input_vector - min_data) / (max_data - min_data)
    return output_vector


def quality_metrics(input_vector, reference):
    input_vector = normalization(input_vector)
    reference = normalization(reference)
    output_vector = np.zeros(6)
    output_vector[0] = scipy.stats.pearsonr(input_vector.reshape(-1), reference.reshape(-1))[0] # pearson
    output_vector[1] = scipy.stats.spearmanr(input_vector, reference)[0] # spearman
    output_vector[2] = scipy.stats.kendalltau(input_vector, reference)[0] # kendall
    output_vector[3] = np.mean(np.power(input_vector-reference,2)) # mse
    output_vector[4] = np.sum(np.power(input_vector-reference,2)) # sse
    output_vector[5] = np.mean(np.absolute(input_vector-reference)) #mae
    return output_vector

def weighted_moving_average(input_vector, weights, window_size):
    output_vector = np.zeros(len(input_vector))
    for i in range(window_size//2, len(input_vector) - (window_size//2)):
        d = input_vector[i - (window_size//2):i + (window_size//2)]
        w = weights[i - (window_size//2):i + (window_size//2)]
        if (np.sum(w) == 0):
            w = np.ones(len(w))*(1/len(w))
        else:
            w = w / np.sum(w)
        output_vector[i] = np.dot(d,w)
    return output_vector

# Files and number of aggregation days
T = 7
# files = os.listdir('ctis_data/')
# files = files[0:5]
files = ['California.csv', 'Texas.csv', 'New York.csv', 'Pennsylvania.csv']

# Official data
us_data = pd.read_csv("us_data.csv", sep=",")
us_data = us_data.transpose()
official_data = pd.DataFrame(columns=[us_data.iloc[1].to_list()])
official_data[us_data.iloc[1].to_list()] = us_data.iloc[2:]

series_aux = official_data.index.to_list()
series_aux = pd.to_datetime(series_aux)
official_data['date'] = series_aux
official_data = official_data[pd.to_datetime(official_data.index.to_list()) > np.datetime64('2020-09-08')]
official_data = official_data[pd.to_datetime(official_data.index.to_list()) < np.datetime64('2022-03-01')]


official    = []
dates_x     = []
household   = []
directraw   = []
directmav   = []
movingavg   = []
community   = []
nsum        = []

for f in files:
    print(f)
    data = pd.read_csv("ctis_data/" + f, sep=",")
    data['EndDatetime'] = pd.to_datetime(data['EndDatetime']).dt.date
    data = data[data['EndDatetime'] > np.datetime64('2020-09-07')]
    data = data[data['EndDatetime'] < np.datetime64('2022-03-01')] 
    household_data  = data.copy()
    household_data = household_data[['EndDatetime', 
                                     'A2', 
                                     'A1_1', 
                                     'A1_3', 
                                     'A1_4', 
                                     'A1_5',
                                     'A4', 
                                     'A2b',
                                     'A5_1', 
                                     'A5_2', 
                                     'A5_3',
                                     'weight']]
    direct_data = data.copy()
    direct_data = direct_data[['EndDatetime', 
                                     'B10a', 
                                     'B10c']]
    direct_data['B10'] = ((direct_data['B10a'] == 1.0) | (direct_data['B10c'] == 1.0)).astype(int)
    direct_data = direct_data[direct_data['B10'] == 1]
    

    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]._convert(numeric=True)
    household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']] = household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']].fillna(0)
    household_data[['A2b']] = household_data[['A2b']].fillna(0)
    household_data['A5'] = np.sum(np.array(household_data[['A2b', 'A5_1', 'A5_2', 'A5_3']]),axis=1)
    
    household_data['A4'] = household_data['A4'].astype('float')
    # -------------------------------------------------
    # NaN filtering across rows and outlier filtering
    household_data = household_data.dropna(axis=0)    
    UB = household_data['A2'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A2'] > 0) & (household_data['A2'] < UB)]
    UB = household_data['A4'].quantile(0.975) # upper bound
    household_data = household_data.loc[(household_data['A4'] > 0) & (household_data['A4'] < UB)]
    # Defining household CLI
    household_data['CLI'] = (household_data['A1_1'] == 1) & ((household_data['A1_3'] ==1) | (household_data['A1_4'] == 1) | (household_data['A1_3'] == 1))
    household_data['A2'] = np.multiply(household_data['A2'], household_data['CLI'].astype(float))
    
    cli_condition = (household_data['A2'] > 0) | (household_data['A4'] > 0) 
    cli_data = household_data.copy()
    cli_data = cli_data[cli_condition == True]
    cli_data['A4'] = np.multiply(cli_data['A2'] + cli_data['A4'], cli_data['CLI'].astype(float))

    # -------------------------------------------------
    # Extracting information from the facebook dataset    
    dates = np.unique(household_data['EndDatetime'])
    indirect_raw = np.zeros(len(dates))
    direct_raw = np.zeros(len(dates))
    cli_raw = np.zeros(len(dates))
    official_cum_cases = np.zeros(len(dates))
    no_responses1 = np.zeros(len(dates))
    no_responses2 = np.zeros(len(dates))
    no_responses3 = np.zeros(len(dates))
    for i in range(len(dates)):
        indirect_raw[i] = np.sum(household_data['A2'][household_data['EndDatetime'] == dates[i]])
        no_responses1[i] = household_data['A2'][household_data['EndDatetime'] == dates[i]].shape[0]
        direct_raw[i] = np.sum(direct_data['B10'][direct_data['EndDatetime'] == dates[i]])
        no_responses2[i] = direct_data['B10'][direct_data['EndDatetime'] == dates[i]].shape[0]
        cli_raw[i] = np.sum(cli_data['A4'][cli_data['EndDatetime'] == dates[i]])
        no_responses3[i] = cli_data['A4'][cli_data['EndDatetime'] == dates[i]].shape[0]
        official_cum_cases[i] = np.sum(official_data[f.replace('.csv', '')][pd.to_datetime(official_data.index.to_list()).date == dates[i]])
        
    indirect_raw_cum = np.cumsum(indirect_raw)
    indirect_raw_stt = np.diff(indirect_raw_cum[T-1::T])      
    direct_raw_cum = np.cumsum(direct_raw)
    direct_raw_stt = np.diff(direct_raw_cum[T-1::T])   
    cli_raw_cum = np.cumsum(cli_raw)
    cli_raw_stt = np.diff(cli_raw_cum[T-1::T])    
    
    w_cum1 = np.cumsum(no_responses1)
    weights1 = np.diff(w_cum1[T-1::T])
    w_cum2 = np.cumsum(no_responses2)
    weights2 = np.diff(w_cum2[T-1::T])
    w_cum3 = np.cumsum(no_responses3)
    weights3 = np.diff(w_cum3[T-1::T])
    
    
    # -------------------------------------------------
    # Raw data
    official_new_cases = np.diff(official_cum_cases[T-1::T].T)
    # -------------------------------------------------
    # Moving average
    window_size = 5
    # mvavg = np.convolve(indirect_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavg = weighted_moving_average(indirect_raw_stt, weights1, window_size)
    mvavg = mvavg[(window_size//2):len(mvavg) - (window_size//2)]
    
    # mvavd = np.convolve(direct_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavd = weighted_moving_average(direct_raw_stt, weights2, window_size)
    mvavd = mvavd[(window_size//2):len(mvavd) - (window_size//2)]
    
    # mvavc = np.convolve(cli_raw_stt, np.ones((window_size,))/window_size, mode='same')
    mvavc = weighted_moving_average(cli_raw_stt, weights3, window_size)
    mvavc = mvavc[(window_size//2):len(mvavc) - (window_size//2)]
    
    indirect_raw_stt = indirect_raw_stt[(window_size//2):len(indirect_raw_stt) - (window_size//2)]
    direct_raw_stt = direct_raw_stt[(window_size//2):len(direct_raw_stt) - (window_size//2)]
    official_new_cases = official_new_cases.T[(window_size//2):len(official_new_cases) - (window_size//2)]
    
    agg_dates = dates[T-1::T]
    agg_dates = agg_dates[1 + (window_size//2):len(agg_dates) - (window_size//2)]
    
    official.append(normalization(official_new_cases.reshape(-1,1)))
    household.append(normalization(indirect_raw_stt.reshape(-1,1)))
    directraw.append(normalization(direct_raw_stt.reshape(-1,1)))
    movingavg.append(normalization(mvavg.reshape(-1,1)))
    directmav.append(normalization(mvavd.reshape(-1,1)))
    community.append(normalization(mvavc.reshape(-1,1)))
    
    dates_x.append(agg_dates.reshape(-1,1))




results_to_save = pd.DataFrame(columns=['state', 
                                        'pearson_raw', 
                                        'spearman_raw', 
                                        'kendall_raw', 
                                        'mse_raw',
                                        'sse_raw',
                                        'mae_raw',
                                        'pearson_mavg', 
                                        'spearman_mavg', 
                                        'kendall_mavg', 
                                        'mse_mavg',
                                        'sse_mavg',
                                        'mae_mavg',
                                        'pearson_community', 
                                        'spearman_community', 
                                        'kendall_community', 
                                        'mse_community',
                                        'sse_community',
                                        'mae_community',
                                        'pearson_direct', 
                                        'spearman_direct', 
                                        'kendall_direct', 
                                        'mse_direct',
                                        'sse_direct',
                                        'mae_direct',
                                        'pearson_nsum', 
                                        'spearman_nsum', 
                                        'kendall_nsum', 
                                        'mse_nsum',
                                        'sse_nsum',
                                        'mae_nsum'])


new_colors = ['#0072BD', '#D95319', '#EDB120', '#7E2F8E',
              '#77AC30', '#4DBEEE', '#A2142F', '#7f7f7f',
              '#bcbd22', '#17becf']

for i in range(len(files)):
    data_temp1 = pd.DataFrame([files[i].replace('.csv', '')],
                              columns=['state'])    
    
    metrics_raw = quality_metrics(household[i], official[i])
    data_temp2 = pd.DataFrame(metrics_raw.reshape(6, 1).T,
                              columns=['pearson_raw', 
                                      'spearman_raw', 
                                      'kendall_raw', 
                                      'mse_raw',
                                      'sse_raw',
                                      'mae_raw'])
    
    metrics_mav = quality_metrics(movingavg[i], official[i])
    data_temp3 = pd.DataFrame(metrics_mav.reshape(6, 1).T,
                              columns=['pearson_mavg', 
                                      'spearman_mavg', 
                                      'kendall_mavg', 
                                      'mse_mavg',
                                      'sse_mavg',
                                      'mae_mavg'])
    
    metrics_com = quality_metrics(community[i], official[i])
    data_temp4 = pd.DataFrame(metrics_com.reshape(6, 1).T,
                              columns=['pearson_community', 
                                      'spearman_community', 
                                      'kendall_community', 
                                      'mse_community',
                                      'sse_community',
                                      'mae_community'])
    
    metrics_dir = quality_metrics(directmav[i], official[i])
    data_temp5 = pd.DataFrame(metrics_dir.reshape(6, 1).T,
                              columns=['pearson_direct', 
                                      'spearman_direct', 
                                      'kendall_direct', 
                                      'mse_direct',
                                      'sse_direct',
                                      'mae_direct'])
    
    
    data_temp = pd.concat([data_temp1, data_temp2, data_temp3, data_temp4, data_temp5],axis=1)
    results_to_save = pd.concat([results_to_save, data_temp])
    
    fig = plt.figure(dpi=300, figsize=(10,2))
    plt.gca().xaxis.set_major_formatter(dtFmt) 
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=4))
    plt.plot(dates_x[i], directmav[i], 'd-', c = new_colors[0], fillstyle='none', lw = 1,label='Direct')
    plt.plot(dates_x[i], movingavg[i], 'o-', c = new_colors[1], fillstyle='none', lw = 1, label='Household')
    plt.plot(dates_x[i], community[i], 's-', c = new_colors[2], fillstyle='none', lw = 1, label='Community')
    plt.plot(dates_x[i], official[i], 'd-', c = new_colors[3], fillstyle='none', lw = 1, label='Official')
    plt.autoscale(enable=True, axis='x', tight=True)
    plt.ylabel('Incidence', fontsize=16, fontweight='bold')
    plt.xticks(fontsize=14, fontweight='bold')
    plt.yticks(fontsize=14, fontweight='bold')
    plt.legend(fontsize=12)
    plt.title(files[i].replace('.csv', ''), fontsize=16, fontweight='bold')
    plt.savefig('ctis_incidence_curves/agg%dd/svg_figures/'%(T) + files[i].replace('.csv', '') + '.svg', bbox_inches='tight')
    plt.show()

results_to_save.to_csv('ctis_incidence_curves/agg%dd/quality_metrics.csv'%(T), sep=',')